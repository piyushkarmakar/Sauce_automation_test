# -*- coding: utf-8 -*-

!pip install webdriver-manager

from behave import given, when, then
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage

@given('I am on the Demo Login Page')
def step_impl(context):
    context.driver = webdriver.Chrome(ChromeDriverManager().install())
    context.driver.get("https://www.saucedemo.com/")
    context.login_page = LoginPage(context.driver)

@when('I fill the account information for account {user_type} into the Username field and the Password field')
def step_impl(context, user_type):
    users = {
        "StandardUser": ("standard_user", "secret_sauce"),
        "LockedOutUser": ("locked_out_user", "secret_sauce")
    }
    username, password = users[user_type]
    context.login_page.login(username, password)

@then('I am redirected to the Demo Main Page')
def step_impl(context):
    assert "inventory.html" in context.driver.current_url

@then('I verify the App Logo exists')
def step_impl(context):
    inventory_page = InventoryPage(context.driver)
    assert inventory_page.is_logo_present()
