# -*- coding: utf-8 -*-
!pip install selenium
!pip install behave
!pip install pytest
import subprocess

subprocess.run(["behave"])

